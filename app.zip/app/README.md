# LAFA Student Records

A Flask-based student record keeping tool for LAFA (Learn Anything From Anywhere) that creates shareable credential pages with unique URLs.

## Features

- **Student Registration**: Simple form to register students with course details
- **Unique URLs**: Each student gets a unique shareable URL for their credential
- **Global Access**: Records can be viewed from anywhere in the world on any device
- **Responsive Design**: Mobile-friendly interface with Bootstrap
- **Print Support**: Print-ready credential cards
- **Secure Storage**: JSON-based data storage with backup functionality

## Installation

1. Extract the zip file to your preferred directory
2. Install Python 3.11 or higher
3. Install dependencies:
   ```bash
   pip install flask flask-sqlalchemy gunicorn psycopg2-binary werkzeug email-validator
   ```

## Deployment Options

### Option 1: Heroku (Free Tier Available)
1. Create a new Heroku app
2. Upload your project files
3. Set environment variable: `SESSION_SECRET=your-secret-key`
4. Deploy using Git or Heroku CLI

### Option 2: Railway
1. Connect your GitHub repository
2. Deploy automatically with Railway
3. Set environment variable: `SESSION_SECRET=your-secret-key`

### Option 3: Render
1. Create a new web service
2. Connect your repository
3. Set build command: `pip install -r requirements.txt`
4. Set start command: `gunicorn --bind 0.0.0.0:$PORT main:app`

### Option 4: PythonAnywhere
1. Upload files to your account
2. Create a new web app with Flask
3. Configure WSGI file to point to main.py

## Local Development

```bash
python main.py
```

Visit `http://localhost:5000` to access the application.

## Environment Variables

- `SESSION_SECRET`: Secret key for Flask sessions (required for production)

## File Structure

```
lafa-student-records/
├── app.py                 # Main Flask application
├── main.py               # Entry point
├── pyproject.toml        # Python dependencies
├── templates/            # HTML templates
│   ├── base.html
│   ├── index.html
│   ├── register.html
│   └── record.html
├── static/               # Static assets
│   ├── css/style.css
│   ├── js/main.js
│   └── images/logo.svg
└── data/                 # Data storage
    └── records.json
```

## Usage

1. **Register Student**: Fill out the registration form with student details
2. **Get Unique URL**: System generates a unique URL for the student record
3. **Share Credential**: Share the URL globally for credential verification
4. **View Records**: Browse all registered students or access individual records

## Security Notes

- Set a strong `SESSION_SECRET` in production
- Consider implementing rate limiting for production use
- Regular backups of `data/records.json` recommended

## Support

For questions about LAFA platform, visit: https://learnanythinganywhere.wordpress.com/2025/05/27/explore-the-world-of-knowledge/

## License

Created for LAFA (Learn Anything From Anywhere) platform.