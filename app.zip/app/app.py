import os
import json
import uuid
import logging
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, abort
from werkzeug.exceptions import NotFound

# Set up logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")

# Data file path
DATA_FILE = 'data/records.json'

def load_records():
    """Load student records from JSON file"""
    try:
        if os.path.exists(DATA_FILE):
            with open(DATA_FILE, 'r') as f:
                return json.load(f)
        return {}
    except Exception as e:
        logging.error(f"Error loading records: {e}")
        return {}

def save_records(records):
    """Save student records to JSON file"""
    try:
        os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
        with open(DATA_FILE, 'w') as f:
            json.dump(records, f, indent=2)
        return True
    except Exception as e:
        logging.error(f"Error saving records: {e}")
        return False

def generate_unique_id():
    """Generate a unique ID for student records"""
    return str(uuid.uuid4())

@app.route('/')
def index():
    """Home page with navigation to register or view records"""
    records = load_records()
    total_records = len(records)
    return render_template('index.html', total_records=total_records)

@app.route('/register', methods=['GET', 'POST'])
def register():
    """Student registration form"""
    if request.method == 'POST':
        # Get form data
        student_name = request.form.get('student_name', '').strip()
        institute = request.form.get('institute', '').strip()
        course_link = request.form.get('course_link', '').strip()
        course_name = request.form.get('course_name', '').strip()
        date = request.form.get('date', '').strip()
        
        # Validate required fields
        if not all([student_name, institute, course_link, course_name, date]):
            flash('All fields are required. Please fill in all information.', 'error')
            return render_template('register.html')
        
        # Validate URL format
        if not (course_link.startswith('http://') or course_link.startswith('https://')):
            course_link = 'https://' + course_link
        
        # Generate unique ID
        record_id = generate_unique_id()
        
        # Create record
        record_data = {
            'id': record_id,
            'student_name': student_name,
            'institute': institute,
            'course_link': course_link,
            'course_name': course_name,
            'date': date,
            'created_at': datetime.now().isoformat(),
            'lafa_about_link': 'https://learnanythinganywhere.wordpress.com/2025/05/27/explore-the-world-of-knowledge/'
        }
        
        # Load existing records and add new one
        records = load_records()
        records[record_id] = record_data
        
        # Save records
        if save_records(records):
            flash(f'Student record created successfully! Your unique URL is: {request.url_root}record/{record_id}', 'success')
            return redirect(url_for('record', record_id=record_id))
        else:
            flash('Error saving record. Please try again.', 'error')
    
    return render_template('register.html')

@app.route('/record/<record_id>')
def record(record_id):
    """Display individual student record"""
    records = load_records()
    
    if record_id not in records:
        abort(404)
    
    record_data = records[record_id]
    record_url = request.url
    
    return render_template('record.html', record=record_data, record_url=record_url)

@app.route('/browse')
def browse():
    """Browse all student records"""
    records = load_records()
    records_list = list(records.values())
    # Sort by creation date, newest first
    records_list.sort(key=lambda x: x.get('created_at', ''), reverse=True)
    
    return render_template('index.html', records=records_list, show_browse=True)

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return render_template('base.html', error_message="Record not found. Please check the URL and try again."), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
